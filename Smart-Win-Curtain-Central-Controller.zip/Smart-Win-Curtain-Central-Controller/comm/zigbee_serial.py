from __future__ import annotations
import serial
from typing import Optional

class ZigBeeSerial:
    """
    Simple framed protocol:
      Incoming: $DATA,L,T,AQ,PIR,SLOT,ANGLE#
      Outgoing: $CMD,ANGLE#
      (You can also extend to $LIGHT,PWM# if you later add a light node.)
    """
    def __init__(self, port: str, baudrate: int, timeout_s: float = 0.2):
        self.ser = serial.Serial(port=port, baudrate=baudrate, timeout=timeout_s)

    def read_frame(self) -> Optional[str]:
        """
        Reads until '#' terminator. Returns full message without trailing '#', or None.
        """
        buf = bytearray()
        while True:
            b = self.ser.read(1)
            if not b:
                return None
            if b == b'#':
                break
            buf += b
            # prevent runaway
            if len(buf) > 256:
                return None
        try:
            return buf.decode("utf-8", errors="ignore").strip()
        except Exception:
            return None

    def send_cmd_angle(self, angle: float) -> None:
        msg = f"$CMD,{angle:.1f}#"
        self.ser.write(msg.encode("utf-8"))

    def close(self) -> None:
        try:
            self.ser.close()
        except Exception:
            pass
