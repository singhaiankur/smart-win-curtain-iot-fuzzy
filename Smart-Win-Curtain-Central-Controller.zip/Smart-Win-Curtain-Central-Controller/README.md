# Smart Win-Curtain Central Controller (Raspberry Pi)

Receives sensor data from the Arduino curtain node via ZigBee (serial), logs data to CSV,
and computes an artificial light PWM command. Optionally sends updated curtain angle commands.

## Install
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
