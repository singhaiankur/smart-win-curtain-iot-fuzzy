# Serial port settings (adjust for your Raspberry Pi)
SERIAL_PORT = "/dev/ttyUSB0"      # e.g., /dev/ttyUSB0 or /dev/ttyAMA0
BAUDRATE = 9600
READ_TIMEOUT_S = 0.2

# Comfort band for normalized light (%) used in paper (example: 35–45)
COMFORT_LOW = 35.0
COMFORT_HIGH = 45.0

# Default policies
SEND_CURTAIN_CMD = False          # set True if you want central override
LOG_PATH = "logs/wincurtain_log.csv"

# Safety clamp for curtain angle (0=open, 75=closed)
ANGLE_MIN = 0.0
ANGLE_MAX = 75.0

# PWM output range for artificial lighting (0..100%)
PWM_MIN = 0.0
PWM_MAX = 100.0

python main.py