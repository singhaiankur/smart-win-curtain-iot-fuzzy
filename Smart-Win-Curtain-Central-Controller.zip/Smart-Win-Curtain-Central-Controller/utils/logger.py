from __future__ import annotations
import csv
import os
from datetime import datetime
from typing import Dict, Any

class CSVLogger:
    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self._init_file()

    def _init_file(self) -> None:
        if os.path.exists(self.path):
            return
        with open(self.path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow([
                "timestamp",
                "light_pct",
                "temp_c",
                "air_rel",
                "pir",
                "slot",
                "curtain_angle",
                "pwm_light_cmd",
                "comfort_ok"
            ])

    def write_row(self, row: Dict[str, Any]) -> None:
        with open(self.path, "a", newline="") as f:
            w = csv.writer(f)
            w.writerow([
                datetime.now().isoformat(timespec="seconds"),
                row["light_pct"],
                row["temp_c"],
                row["air_rel"],
                row["pir"],
                row["slot"],
                row["curtain_angle"],
                row["pwm_light_cmd"],
                row["comfort_ok"],
            ])
