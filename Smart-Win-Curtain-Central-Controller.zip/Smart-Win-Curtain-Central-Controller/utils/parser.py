from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

@dataclass
class CurtainPacket:
    light: float     # 0..100 (normalized)
    temp: float      # °C
    air: float       # 0..1000 (relative)
    pir: int         # 0/1
    slot: int        # 0 sleep, 1 work, 2 relax
    angle: float     # 0..75

def parse_data_frame(frame: str) -> Optional[CurtainPacket]:
    """
    frame: "$DATA,L,T,AQ,PIR,SLOT,ANGLE"
    """
    if not frame.startswith("$DATA"):
        return None
    parts = frame.split(",")
    if len(parts) != 7:
        return None
    try:
        return CurtainPacket(
            light=float(parts[1]),
            temp=float(parts[2]),
            air=float(parts[3]),
            pir=int(parts[4]),
            slot=int(parts[5]),
            angle=float(parts[6]),
        )
    except ValueError:
        return None
