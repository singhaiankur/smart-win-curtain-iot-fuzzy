from __future__ import annotations

def clamp(x: float, lo: float, hi: float) -> float:
    return lo if x < lo else hi if x > hi else x

class CurtainSupervisor:
    """
    Optional: central override of curtain angle.
    By default, you can keep SEND_CURTAIN_CMD=False and let Arduino handle curtain locally.
    """
    def __init__(self, angle_min: float, angle_max: float):
        self.angle_min = angle_min
        self.angle_max = angle_max

    def maybe_override(self, current_angle: float, light_pct: float, temp_c: float, air_rel: float) -> float:
        # Conservative placeholder: do not override
        # You can implement policy later if needed.
        return clamp(current_angle, self.angle_min, self.angle_max)
