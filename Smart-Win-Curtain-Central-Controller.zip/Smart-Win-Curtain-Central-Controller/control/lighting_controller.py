from __future__ import annotations
from dataclasses import dataclass

@dataclass
class LightingDecision:
    pwm_percent: float
    comfort_ok: int

def clamp(x: float, lo: float, hi: float) -> float:
    return lo if x < lo else hi if x > hi else x

class LightingController:
    """
    Central controller computes artificial light PWM (%) from measured indoor light (%).
    Conservative, paper-friendly:
      - if occupied (PIR=1), keep light within comfort band [low, high]
      - if not occupied, keep PWM low/off
    """
    def __init__(self, comfort_low: float, comfort_high: float, pwm_min: float, pwm_max: float):
        self.comfort_low = comfort_low
        self.comfort_high = comfort_high
        self.pwm_min = pwm_min
        self.pwm_max = pwm_max

    def compute_pwm(self, light_pct: float, pir: int) -> LightingDecision:
        if pir == 0:
            return LightingDecision(pwm_percent=0.0, comfort_ok=0)

        # simple proportional fill to reach midpoint of comfort band
        target = 0.5 * (self.comfort_low + self.comfort_high)
        error = target - light_pct

        # Convert error to PWM command (tunable gain)
        k = 2.0  # %PWM per %light error
        pwm = k * error

        # base lighting to avoid too dim
        base = 10.0
        pwm = clamp(base + pwm, self.pwm_min, self.pwm_max)

        comfort_ok = int(self.comfort_low <= light_pct <= self.comfort_high)
        return LightingDecision(pwm_percent=pwm, comfort_ok=comfort_ok)
