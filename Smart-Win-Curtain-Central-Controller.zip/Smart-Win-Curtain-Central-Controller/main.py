from __future__ import annotations

import time
from comm.zigbee_serial import ZigBeeSerial
from utils.parser import parse_data_frame
from utils.logger import CSVLogger
from control.lighting_controller import LightingController
from control.curtain_supervisor import CurtainSupervisor
import config

def main() -> None:
    zb = ZigBeeSerial(config.SERIAL_PORT, config.BAUDRATE, config.READ_TIMEOUT_S)
    logger = CSVLogger(config.LOG_PATH)

    light_ctrl = LightingController(
        comfort_low=config.COMFORT_LOW,
        comfort_high=config.COMFORT_HIGH,
        pwm_min=config.PWM_MIN,
        pwm_max=config.PWM_MAX,
    )

    curtain_sup = CurtainSupervisor(config.ANGLE_MIN, config.ANGLE_MAX)

    print("Central Controller started. Listening for $DATA frames...")

    try:
        while True:
            frame = zb.read_frame()
            if frame is None:
                time.sleep(0.05)
                continue

            pkt = parse_data_frame(frame)
            if pkt is None:
                continue

            # Compute artificial light PWM command (central)
            decision = light_ctrl.compute_pwm(pkt.light, pkt.pir)

            # Log for paper analysis
            logger.write_row({
                "light_pct": round(pkt.light, 2),
                "temp_c": round(pkt.temp, 2),
                "air_rel": round(pkt.air, 0),
                "pir": pkt.pir,
                "slot": pkt.slot,
                "curtain_angle": round(pkt.angle, 2),
                "pwm_light_cmd": round(decision.pwm_percent, 2),
                "comfort_ok": decision.comfort_ok
            })

            # Optional: central override of curtain angle
            if config.SEND_CURTAIN_CMD:
                new_angle = curtain_sup.maybe_override(pkt.angle, pkt.light, pkt.temp, pkt.air)
                zb.send_cmd_angle(new_angle)

            # Console print (optional)
            print(
                f"L={pkt.light:5.1f}%  T={pkt.temp:4.1f}C  AQ={pkt.air:5.0f}  PIR={pkt.pir}  "
                f"SLOT={pkt.slot}  ANG={pkt.angle:5.1f}  PWM={decision.pwm_percent:5.1f}%"
            )

    except KeyboardInterrupt:
        print("\nStopping...")
    finally:
        zb.close()

if __name__ == "__main__":
    main()
