#include "communication.h"
#include "config.h"

SoftwareSerial zigbee(ZB_RX, ZB_TX);

void zigbeeInit() {
  zigbee.begin(9600);
}

void sendToCentral(SensorData d, float angle) {
  zigbee.print("$DATA,");
  zigbee.print(d.light); zigbee.print(",");
  zigbee.print(d.temp);  zigbee.print(",");
  zigbee.print(d.air);   zigbee.print(",");
  zigbee.print(d.pir);   zigbee.print(",");
  zigbee.print(d.slot);  zigbee.print(",");
  zigbee.print(angle);
  zigbee.println("#");
}

bool receiveFromCentral(float &angle) {
  static String buf = "";
  while (zigbee.available()) {
    char c = zigbee.read();
    if (c == '#') {
      if (buf.startsWith("$CMD")) {
        angle = buf.substring(buf.indexOf(',') + 1).toFloat();
        buf = "";
        return true;
      }
      buf = "";
    } else buf += c;
  }
  return false;
}
