# Smart Win-Curtain Controller (Arduino)

This repository contains the Arduino-based curtain controller for an
IoT-enabled smart win-curtain system using fuzzy logic and ZigBee communication.

## Features
- Fuzzy logic–based curtain angle control
- LDR, LM35, MQ-135, PIR sensor integration
- ZigBee-based communication with central controller
- Modular, reproducible code structure

## Hardware
- Arduino UNO / ATmega328P
- Servo motor (0–75° curtain angle)
- ZigBee (IEEE 802.15.4)
- LDR, LM35, MQ-135, PIR

