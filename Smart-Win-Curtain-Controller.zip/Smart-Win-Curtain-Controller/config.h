#ifndef CONFIG_H
#define CONFIG_H

#include <SoftwareSerial.h>

// Pins
#define PIN_LDR    A0
#define PIN_LM35   A1
#define PIN_MQ135  A2
#define PIN_PIR    2
#define PIN_SERVO  9

#define ZB_RX 10
#define ZB_TX 11

extern SoftwareSerial zigbee;

// Limits
#define ANGLE_MIN 0
#define ANGLE_MAX 75

// ADC reference
#define ADC_REF_V 5.0

#endif
