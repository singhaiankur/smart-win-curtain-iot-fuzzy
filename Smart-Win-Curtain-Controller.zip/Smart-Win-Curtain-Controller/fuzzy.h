#ifndef FUZZY_H
#define FUZZY_H

#include "sensors.h"

float computeCurtainAngle(
  float light, float temp, float air,
  float prevAngle, Slot slot, int pir
);

#endif
