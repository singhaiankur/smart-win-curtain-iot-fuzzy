#ifndef UTILS_H
#define UTILS_H

float clampf(float x, float lo, float hi);
float trimf(float x, float a, float b, float c);
float trapmf(float x, float a, float b, float c, float d);

#endif
