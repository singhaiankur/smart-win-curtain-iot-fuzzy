#ifndef COMMUNICATION_H
#define COMMUNICATION_H

#include "sensors.h"
#include <SoftwareSerial.h>

extern SoftwareSerial zigbee;

void zigbeeInit();
void sendToCentral(SensorData data, float angle);
bool receiveFromCentral(float &angle);

#endif
