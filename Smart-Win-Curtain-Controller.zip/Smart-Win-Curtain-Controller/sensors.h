#ifndef SENSORS_H
#define SENSORS_H

#include "config.h"

enum Slot { SLEEP = 0, WORK = 1, RELAX = 2 };

struct SensorData {
  float light;
  float temp;
  float air;
  int pir;
  Slot slot;
};

void initSensors();
SensorData readAllSensors();

#endif
