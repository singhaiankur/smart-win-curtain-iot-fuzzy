#include "sensors.h"

void initSensors() {
  pinMode(PIN_PIR, INPUT);
}

float readLight() {
  return map(analogRead(PIN_LDR), 0, 1023, 0, 100);
}

float readTemp() {
  float v = analogRead(PIN_LM35) * ADC_REF_V / 1023.0;
  return v / 0.01;
}

float readAir() {
  return map(analogRead(PIN_MQ135), 0, 1023, 0, 1000);
}

Slot readSlot(int pir) {
  return pir ? WORK : SLEEP;
}

SensorData readAllSensors() {
  SensorData d;
  d.light = readLight();
  d.temp  = readTemp();
  d.air   = readAir();
  d.pir   = digitalRead(PIN_PIR);
  d.slot  = readSlot(d.pir);
  return d;
}
