#include "fuzzy.h"
#include "utils.h"

float computeCurtainAngle(
  float light, float temp, float air,
  float prevAngle, Slot slot, int pir
) {
  float angle = prevAngle;

  if (light > 80) angle = 75;
  else if (light > 50) angle = 45;
  else angle = 15;

  if (temp > 32) angle += 5;
  if (air > 300) angle -= 5;

  return clampf(angle, 0, 75);
}
