#ifndef COMM_ZIGBEE_H
#define COMM_ZIGBEE_H

#include <Arduino.h>

void zigbeeInit(long baud);
bool receiveLightCommand(float &pwmPercent);
void sendLightStatus(float pwmPercent);

#endif
