#include "light_driver.h"
#include "config.h"
#include <Arduino.h>

static float clamp(float x) {
  if (x < PWM_MIN) return PWM_MIN;
  if (x > PWM_MAX) return PWM_MAX;
  return x;
}

void initLightDriver() {
  pinMode(LED_PWM_PIN, OUTPUT);
  analogWrite(LED_PWM_PIN, 0);
}

void setLightPWM(float pwmPercent) {
  pwmPercent = clamp(pwmPercent);
  int pwmValue = (int)(pwmPercent * 255.0 / 100.0);
  analogWrite(LED_PWM_PIN, pwmValue);
}
