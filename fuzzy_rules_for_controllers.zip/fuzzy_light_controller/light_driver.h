#ifndef LIGHT_DRIVER_H
#define LIGHT_DRIVER_H

void initLightDriver();
void setLightPWM(float pwmPercent);

#endif