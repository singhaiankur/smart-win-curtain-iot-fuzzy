#ifndef FALLBACK_CONTROL_H
#define FALLBACK_CONTROL_H

float fallbackThresholdControl();

#endif
