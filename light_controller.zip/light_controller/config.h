#ifndef CONFIG_H
#define CONFIG_H

// ZigBee pins
#define ZB_RX 10
#define ZB_TX 11

// PWM pin for LED driver
#define LED_PWM_PIN 3

// Timeout (ms) before fallback control
#define RX_TIMEOUT_MS 5000

// PWM limits
#define PWM_MIN 0
#define PWM_MAX 100

#endif
