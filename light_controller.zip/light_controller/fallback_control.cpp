#include "fallback_control.h"

// Simple baseline controller (no fuzzy)
float fallbackThresholdControl() {
  return 30.0;   // default comfortable brightness
}
