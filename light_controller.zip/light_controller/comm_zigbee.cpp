#include "comm_zigbee.h"
#include "config.h"
#include <SoftwareSerial.h>

SoftwareSerial zigbee(ZB_RX, ZB_TX);

void zigbeeInit(long baud) {
  zigbee.begin(baud);
}

bool receiveLightCommand(float &pwmPercent) {
  static String buffer = "";

  while (zigbee.available()) {
    char c = zigbee.read();
    if (c == '#') {
      if (buffer.startsWith("$LIGHT")) {
        int idx = buffer.indexOf(',');
        if (idx > 0) {
          pwmPercent = buffer.substring(idx + 1).toFloat();
          buffer = "";
          return true;
        }
      }
      buffer = "";
    } else {
      buffer += c;
    }
  }
  return false;
}

void sendLightStatus(float pwmPercent) {
  zigbee.print("$LSTAT,");
  zigbee.print(pwmPercent, 1);
  zigbee.println("#");
}
